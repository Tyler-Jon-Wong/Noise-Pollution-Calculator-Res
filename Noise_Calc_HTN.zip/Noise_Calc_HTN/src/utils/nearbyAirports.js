const unirest = require("unirest");
const fs = require("fs");

const nearbyAirports = () => {
	//Load CSV file
	const dataBuffer = fs.readFileSync('\database\IATAICAO_converted.json');
	const dataJSON = dataBuffer.toString();
	const finalData = JSON.parse(dataJSON); //array
	console.log(finalData.airports);
	let airports = [];
	let iata;
	let icao = "";
	let counter=0;
	let nearbyAirportsICAO = [];

	var req = unirest("GET", "https://cometari-airportsfinder-v1.p.rapidapi.com/api/airports/by-radius");

	req.query({
		"radius": "50",
		"lng": "-79.725371",
		"lat": "43.636500"
	});



	req.headers({
		"x-rapidapi-host": "cometari-airportsfinder-v1.p.rapidapi.com",
		"x-rapidapi-key": "5b5bf179d1mshe6b2e5bab5cde5dp1baccajsn114e204c8a68"
	});


	req.end(function (res) {
		if (res.error) throw new Error(res.error);
			for (var i=0; i<res.body.length;i++) {
				icao="";
				//airports.push(res.body[i].code);
				iata = res.body[i].code
				for(var j=0;j<finalData.length;j++) {
					if (finalData[j].IATA == res.body[i].code) {
						icao = finalData[j].ICAO;
						nearbyAirportsICAO.push(icao);
						icao = "";
						console.log(nearbyAirportsICAO)
				}
			}
			
		}
	});
		//console.log(nearbyAirportsICAO)
		return nearbyAirportsICAO;
}


console.log()

module.exports = nearbyAirports;